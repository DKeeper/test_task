<?php
/**
 * @author Капенкин Дмитрий <dkapenkin@rambler.ru>
 * @date 04.02.15
 * @time 6:11
 * Created by JetBrains PhpStorm.
 */
return [
    'language'=>'en',
    'baseUrl'=>'/',
    'db' => [
        'dsn' => 'mysql:host=localhost;dbname=test',
        'user' => 'test',
        'password' => 'RerzSwuWPzKvxNNT',
    ],
];